
from flask import Flask, render_template
import pandas as pd
import matplotlib.pyplot as plt
import os

app = Flask(__name__)
os.makedirs("static", exist_ok=True)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/lat-est")
def lat_est():
    df = pd.read_excel("LBL_statistika.xlsx", sheet_name="LAT-EST")
    return render_template("table.html", data=df.to_dict(orient="records"), columns=df.columns, title="Latvijas - Igaunijas basketbola līga (1.līga)", chart_url=None, filter_value=0, league="Latvijas - Igaunijas basketbola līga (1.līga)")

@app.route("/lbl2")
def lbl2():
    df = pd.read_excel("LBL_statistika.xlsx", sheet_name="LBL2")
    return render_template("table.html", data=df.to_dict(orient="records"), columns=df.columns, title="Ramirent Nacionālā basketbola līga (2.līga)", chart_url=None, filter_value=0, league="Ramirent Nacionālā basketbola līga (2.līga)")

@app.route("/lbl3")
def lbl3():
    df = pd.read_excel("LBL_statistika.xlsx", sheet_name="LBL3")
    return render_template("table.html", data=df.to_dict(orient="records"), columns=df.columns, title="Aizdevums.lv Reģionālā basketbola līga (3.līga)", chart_url=None, filter_value=0, league="Aizdevums.lv Reģionālā basketbola līga (3.līga)")

@app.route("/grafiki")
def grafiki():
    print("➡️ Sāku zīmēt grafikus...")
    charts = {}
    leagues = {"LAT-EST": "lat-est", "LBL2": "lbl2", "LBL3": "lbl3"}
    stats = [("PPG", 2), ("RPG", 1), ("APG", 1)]

    df_all = pd.read_excel("LBL_statistika.xlsx", sheet_name=None)

    for sheet_name, route_name in leagues.items():
        df = df_all.get(sheet_name)
        if df is None:
            print(f"❌ Sheet {sheet_name} nav atrasts.")
            continue

        charts[route_name.upper()] = []
        for stat, bin_size in stats:
            if stat not in df.columns:
                print(f"⚠️ {stat} nav kolonna sheetā {sheet_name}")
                continue

            try:
                plt.figure()
                df[stat].dropna().hist(bins=range(0, int(df[stat].max()) + bin_size + 1, bin_size))
                plt.title(f"{sheet_name} – {stat} Histogramma")
                plt.xlabel(stat)
                plt.ylabel("Spēlētāju skaits")
                plt.tight_layout()
                filename = f"{route_name}_{stat.lower()}.png"
                path = os.path.join("static", filename)
                plt.savefig(path)
                plt.close()
                print(f"✅ Saglabāta diagramma: {filename}")
                charts[route_name.upper()].append({"title": stat, "filename": filename})
            except Exception as e:
                print(f"❌ Kļūda zīmējot {stat} priekš {sheet_name}: {e}")

    return render_template("grafiki.html", charts=charts)

if __name__ == "__main__":
    app.run(debug=True)
